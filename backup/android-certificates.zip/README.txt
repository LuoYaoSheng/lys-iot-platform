# Android Certificates Backup

## Files
- key.properties - Signing config (contains password and alias)
- iot-app-release.jks - Release keystore file

## Usage
Place these files in:
- mobile-app/android/key.properties
- mobile-app/android/keystore/iot-app-release.jks

## Build APK
cd mobile-app
flutter build apk --release
